﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFLocalizeExtension.Engine;

namespace MultiLanguage
{
    public static class ChangeLanguageHelper
    {
        /// <summary>
        /// 转换程序语言，默认为当前计算机语言
        /// 需要符合ISO 039-1编码规范
        /// </summary>
        /// <param name="sLanguageCode">计算机语言编码，需要符合ISO 039-1编码规范</param>
        public static void ChangeLanguage(string? sLanguageCode = "")
        {
            if(sLanguageCode == "" || sLanguageCode is null)
            {
                sLanguageCode = CultureInfo.CurrentCulture.TwoLetterISOLanguageName;
            }
            // UNDONE: 多语言切换需要写入配置文件（目前配置文件尚未完成）
            CultureInfo newCulture = CultureInfo.GetCultureInfo(sLanguageCode);
            LocalizeDictionary.Instance.Culture = newCulture;
        }


    }
}
